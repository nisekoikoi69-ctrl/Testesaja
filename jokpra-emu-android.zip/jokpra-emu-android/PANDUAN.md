# Jokpra Emu: panduan pasang ke fork Eden Android

## 1. Siapkan
- Fork https://github.com/diegolix29/Eden-Trigger-Android lalu clone dengan submodule:
  `git clone --recurse-submodules <url-forkmu>`
- Hapus varian `genshinSpoof` dari build.gradle (menyamar sebagai paket aplikasi lain).

## 2. Ganti identitas
- Ubah `applicationId` varian mainline (mis. `org.jokpra.emu`) dan `app_name` di strings.xml jadi "Jokpra Emu".
- Ganti ikon launcher lewat Android Studio: New > Image Asset.

## 3. Tema Switch 2
- Salin folder `res/values` dan `res/values-night` ke `app/src/main/res/`.
- Di tema aplikasi, arahkan `colorPrimary` ke `@color/jokpra_primary`,
  `colorSecondary` ke `@color/jokpra_secondary`, `colorSurface` ke `@color/jokpra_surface`,
  dan `android:colorBackground` ke `@color/jokpra_bg`.

## 4. Login Nextendo
- Salin dua file .kt ke folder package pilihanmu dan sesuaikan baris `package`.
- Tempel isi AndroidManifest-snippet.xml (sesuaikan nama package pada android:name).
- Isi AUTHORIZE_URL, TOKEN_URL, SCOPES di NextendoConfig dari dokumentasi Nextendo.
- Daftarkan `jokpraemu://nextendo/callback` sebagai redirect URI di konsol developer.
- Pasang tombol: `button.setOnClickListener { NextendoAuth.startLogin(this) }`

## 5. Build
`./gradlew assembleMainlineRelease` (hasil di app/build/outputs/apk/mainline/release/)
