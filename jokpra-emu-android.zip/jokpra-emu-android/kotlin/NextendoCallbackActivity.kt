package org.jokpra.emu.nextendo // sesuaikan dengan package fork-mu

import android.app.Activity
import android.os.Bundle
import android.widget.Toast

/** Menerima alamat jokpraemu://nextendo/callback dari browser setelah login. */
class NextendoCallbackActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent?.data
        if (uri == null) {
            finish()
            return
        }
        NextendoAuth.handleCallback(this, uri) { _, message ->
            runOnUiThread {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }
}
