package org.jokpra.emu.nextendo // sesuaikan dengan package fork-mu

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom

object NextendoConfig {
    // ID aplikasi dari URL konsol developer. Cek lagi di tab "general".
    const val CLIENT_ID = "nxc_fKgIE5o5SGzc"

    // Daftarkan persis alamat ini sebagai redirect URI di konsol developer.
    const val REDIRECT_URI = "jokpraemu://nextendo/callback"

    // ISI dari dokumentasi Nextendo. Alamat ini tidak bisa saya lihat dari halaman publik.
    const val AUTHORIZE_URL = "ISI_ALAMAT_AUTHORIZE"
    const val TOKEN_URL = "ISI_ALAMAT_TOKEN"
    const val SCOPES = "ISI_SCOPE" // contoh: scope yang kamu aktifkan di konsol
}

object NextendoAuth {
    private const val PREFS = "nextendo_auth"

    private fun randomUrlSafe(bytes: Int): String {
        val b = ByteArray(bytes)
        SecureRandom().nextBytes(b)
        return Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
    }

    private fun challenge(verifier: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII))
        return Base64.encodeToString(d, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
    }

    /** Buka halaman login Nextendo di browser. Panggil dari tombol "Masuk Nextendo". */
    fun startLogin(context: Context) {
        val verifier = randomUrlSafe(64)
        val state = randomUrlSafe(16)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("verifier", verifier).putString("state", state).apply()

        val uri = Uri.parse(NextendoConfig.AUTHORIZE_URL).buildUpon()
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("client_id", NextendoConfig.CLIENT_ID)
            .appendQueryParameter("redirect_uri", NextendoConfig.REDIRECT_URI)
            .appendQueryParameter("scope", NextendoConfig.SCOPES)
            .appendQueryParameter("state", state)
            .appendQueryParameter("code_challenge", challenge(verifier))
            .appendQueryParameter("code_challenge_method", "S256")
            .build()
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Dipanggil saat browser kembali ke aplikasi. callback(berhasil, pesan) jalan di thread latar. */
    fun handleCallback(context: Context, uri: Uri, callback: (Boolean, String) -> Unit) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val expected = prefs.getString("state", null)
        val verifier = prefs.getString("verifier", null)
        val code = uri.getQueryParameter("code")
        val error = uri.getQueryParameter("error")

        if (error != null) return callback(false, "Login ditolak: $error")
        if (code == null || verifier == null || uri.getQueryParameter("state") != expected) {
            return callback(false, "Respons login tidak valid.")
        }
        Thread {
            try {
                val body = listOf(
                    "grant_type" to "authorization_code",
                    "code" to code,
                    "redirect_uri" to NextendoConfig.REDIRECT_URI,
                    "client_id" to NextendoConfig.CLIENT_ID,
                    "code_verifier" to verifier
                ).joinToString("&") { "${it.first}=${URLEncoder.encode(it.second, "UTF-8")}" }

                val conn = URL(NextendoConfig.TOKEN_URL).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                conn.outputStream.use { it.write(body.toByteArray()) }

                val ok = conn.responseCode in 200..299
                val text = (if (ok) conn.inputStream else conn.errorStream).bufferedReader().readText()
                if (!ok) return@Thread callback(false, "Gagal menukar kode ($text)")

                val json = JSONObject(text)
                // Catatan: untuk rilis, simpan token di EncryptedSharedPreferences.
                prefs.edit()
                    .putString("access_token", json.optString("access_token"))
                    .putString("refresh_token", json.optString("refresh_token"))
                    .remove("verifier").remove("state").apply()
                callback(true, "Berhasil masuk ke Nextendo.")
            } catch (e: Exception) {
                callback(false, "Kesalahan jaringan: ${e.message}")
            }
        }.start()
    }

    fun accessToken(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("access_token", null)

    fun signOut(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
